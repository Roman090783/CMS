<?php
require_once $_SERVER["DOCUMENT_ROOT"] . '/HB/inc/constants.inc.php';

echo Html::getDoctype();
echo Html::openHtmlHtml();

$aCfg["TITLE"] = "Verwaltung";
echo Html::openHtmlHead($aCfg);
?>

<style>
#frmAddNew {
    display: none;
}

#frmAddLieferanten {
    display: none;
}

#frmAddArtikel {
    display: none;
}
</style>
<script>
function checkButton($open) {
    $("#frmAddArtikel").addClass("frmAddArtikel");
}

$(document).ready(function() {
    //button div selectiert + .event
    $("#btnAddNew").on("click", function() {
        $("#frmAddLieferanten").hide();
        $("#frmAddArtikel").hide();
        $("#frmAddNew").slideToggle();
    })
});

$(document).ready(function() {
    //button div selectiert + .event
    $("#btnAddLiferant").on("click", function() {
        $("#frmAddArtikel").hide();
        $("#frmAddNew").hide();
        $("#frmAddLieferanten").slideToggle();
    })
});

$(document).ready(function() {
    //button div selectiert + .event
    $("#btnAddArtikel").on("click", function() {
        $("#frmAddLieferanten").hide();
        $("#frmAddNew").hide();
        $("#frmAddArtikel").slideToggle();
        //var one = $("#frmAddLieferanten");
        //if(){

        //}
    })
});
</script>

<?php
echo Html::closeHtmlHead();
echo Html::openHtmlBody();
?>



<div id="Container" class="container">


    <h1>Bestellplatform Verwaltung</h1>
    <header>
        <?php
        if (isset($_SESSION["admin"])) {
    require $_SERVER["DOCUMENT_ROOT"] . '/HB/inc/navigation.inc.php';
        }
    //Kunde update
    if(isset($_GET['updatek']) && $_GET['updatek'] == 'updateK' && $_GET['id'] != null)
    {
    $pdo = new PDO(DSN, DBUSER, DBPWD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $selectKID = $pdo->query("SELECT * FROM kunden WHERE id = '".$_GET['id']."'"); 
        $DataKID = $selectKID->fetch(PDO::FETCH_ASSOC);
//var_dump($DataKID);
    }

    //Artikel update
    if(isset($_GET['updatea']) && $_GET['updatea'] == 'updateA' && $_GET['ID'] != null)
    {
    $pdo = new PDO(DSN, DBUSER, DBPWD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $selectKID = $pdo->query("SELECT * FROM artikel WHERE ID = '".$_GET['ID']."'"); 
    $DataKID = $selectKID->fetch(PDO::FETCH_ASSOC);
    }

    //Lieferant update
    if(isset($_GET['Lupdate']) && $_GET['Lupdate'] == 'updateL' && $_GET['id'] != null){
        $pdo = new PDO(DSN, DBUSER, DBPWD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $selectLID = $pdo->query("SELECT * FROM lieferant WHERE id = '".$_GET['id']."'"); 
        $DataLID = $selectLID->fetch(PDO::FETCH_ASSOC);
    }
    ?>
    </header>

    <div id="frmAddNew">
        <div>
            <form action="pdo.php" method="POST">
                <form>
                    <div class="form-group">
                        <label for="KFirma">Kunden-Firma: </label>
                        <input type="" name="Kfirma" class="form-control" placeholder="<?= $DataKID['Firma']  ?? "" ?>"
                            value="" class="form-control" id="KFirma"> <!-- required -->
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="elVorname">Vorname: </label>
                            <input type="" name="Kvorname" class="form-control" required
                                placeholder="<?= $DataKID['vorname']  ?? "" ?>" value="" id="elVorname">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="elNachname">Nachame: </label>
                            <input type="" name="Knachname" class="form-control" required
                                placeholder="<?= $DataKID['nachname']  ?? "" ?>" value="" id="elNachname">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="KStr">Straße: </label>
                        <input type="" name="Kstr" class="form-control" required
                            placeholder="<?= $DataKID['Strasse']  ?? "" ?>" value="" id="Kstr">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="KCity">Stadt: </label>
                            <input type="text" name="Kstadt" required placeholder="<?= $DataKID['Stadt']  ?? "" ?>"
                                class="form-control" value="" id="KCity">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="KLand">Land: </label>
                            <input type="text" name="Kland" required placeholder="<?= $DataKID['Land']  ?? "" ?>"
                                class="form-control" value="" id="KLand">
                        </div>
                        <div class="form-group col-md-2">
                            <label for="KZip">Postleitzahl: </label>
                            <input type="text" name="Kplz" required placeholder="<?= $DataKID['PLZ']  ?? "" ?>"
                                class="form-control" value="" id="KZip">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="KMail">E-Mail: </label>
                            <input type="" name="Kemail" required placeholder="<?= $DataKID['Email']  ?? "" ?>"
                                class="form-control" value="" id="KMail">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="KTel">Telefonnummer: </label>
                            <input type="" name="Ktel" required placeholder="<?= $DataKID['Tel']  ?? "" ?>"
                                class="form-control" value="" id="KTel">
                        </div>
                    </div>

                    <div>
                        <?php 
                        if (isset($_GET['updatek']) && $_GET['updatek'] == 'updateK' && $_GET['id'] != null) {
                        ?>
                        <input type="hidden" id="custId" name="custID" value="<?= $_GET['id'] ?>">
                        <input type="submit" class="btn btn-secondary btn-sm" name="speichernKFinll" value="Speihern"
                            id="SKunde">
                        <?php
                        } else {
                        ?>
                        <input type="submit" class="btn btn-secondary btn-sm" name="speichernK" value="Speihern"
                            id="SKunde">
                        <?php
                        }
                        ?>
                    </div>
                </form>
            </form>
        </div>
    </div>
    <?php
    if(isset($_GET['updatek']) && $_GET['updatek'] == 'updateK' && $_GET['id'] != null)
    {
        ?>
    <script>
    $("#frmAddNew").slideToggle();
    </script>
    <?
    }
    ?>

    <div id="frmAddArtikel">
        <div>
            <form action="pdo.php" method="POST">
                <form>
                    <div class="form-row">

                        <div class="form-group col-md-2">
                            <label for="artID">Artikel-Nr: </label>
                            <input type="text" name="ArtNr" required class="form-control"
                                placeholder="<?= $DataKID['ArtikelNr']  ?? "" ?>" id="artID">
                        </div>

                        <div class="form-group col-md-5">
                            <label for="AName">Artikel-Name: </label>
                            <input type="text" name="artikel" required class="form-control"
                                placeholder="<?= $DataKID['name']  ?? "" ?>" id="AName">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="APreis">Verkaufspreis: </label>
                            <input type="text" name="preis" required class="form-control"
                                placeholder="<?= $DataKID['preis']  ?? "" ?>" id="APreis">
                        </div>
                        <div class="form-group col-md-2">
                            <label for="ABestand">Lagerbestand: </label>
                            <input type="text" name="bestand" required class="form-control"
                                placeholder="<?= $DataKID['bestand']  ?? "" ?>" id="ABestand">
                        </div>
                    </div>

                    <div>
                        <?php 
                        if (isset($_GET['updatea']) && $_GET['updatea'] == 'updateA' && $_GET['ID'] != null) {
                        ?>
                        <input type="hidden" id="AId" name="AID" value="<?= $_GET['ID'] ?>">
                        <input type="submit" class="btn btn-secondary btn-sm" name="speichernAA" value="Speihern"
                            id="SArtikel">
                        <?php
                        } else {
                        ?>
                        <input type="submit" class="btn btn-secondary btn-sm" name="speichernArt" value="speichernArt"
                            id="SArtikel">
                        <?php
                        }
                        ?>

                    </div>
                </form>
            </form>
        </div>
    </div>

    <?php
    if(isset($_GET['updatea']) && $_GET['updatea'] == 'updateA' && $_GET['ID'] != null)
    {
        ?>
    <script>
    $("#frmAddArtikel").slideToggle();
    </script>
    <?
    }
    ?>

    <div id="frmAddLieferanten">
        <div>
            <form action="pdo.php" method="POST">
                <form>
                    <div class="form-group">
                        <label for="LFirma">Lieferant Firma: </label>
                        <input type="" name="LFirma" class="form-control" value="" required
                            placeholder="<?= $DataLID['Firma']  ?? "" ?>" id="LFirma">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="LVorname">Vorname: </label>
                            <input type="" name="LVorname" class="form-control" value="" required
                                placeholder="<?= $DataLID['vorname']  ?? "" ?>" id="LVorname">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="LNachname">Nachame: </label>
                            <input type="" name="LNachname" class="form-control" value="" required
                                placeholder="<?= $DataLID['nachname']  ?? "" ?>" id="LNachname">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="elpass">Passwort: </label>
                            <input type="" name="passwort" class="form-control" value="" required
                                placeholder="<?= $DataLID['passwort']  ?? "" ?>" id="elpass">
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="LStr">Straße: </label>
                        <input type="" name="LStr" class="form-control" value="" required
                            placeholder="<?= $DataLID['Strasse']  ?? "" ?>" id="LStr">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="LCity">Stadt: </label>
                            <input type="text" name="LCity" class="form-control" required
                                placeholder="<?= $DataLID['Stadt']  ?? "" ?>" id="LCity">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="LLand">Land: </label>
                            <input type="text" name="LLand" class="form-control" required
                                placeholder="<?= $DataLID['Land']  ?? "" ?>" id="LLand">
                        </div>
                        <div class="form-group col-md-2">
                            <label for="LPLZ">Postleitzahl: </label>
                            <input type="text" name="LPLZ" class="form-control" required
                                placeholder="<?= $DataLID['PLZ']  ?? "" ?>" id="LPLZ">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="LMail">E-Mail: </label>
                            <input type="" name="LEmail" value="" required placeholder="<?= $DataLID['Email']  ?? "" ?>"
                                id="LMail">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="LTel">Telefonnummer: </label>
                            <input type="" name="LTel" value="" required placeholder="<?= $DataLID['Tel']  ?? "" ?>"
                                id="LTel">
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="status">Type:</label>
                        <select id="status" name="Lusertype">
                            <option value="lieferant">lieferant</option>
                            <option value="administrator">Administrator</option>
                        </select>
                    </div>
                    <div>
                        <?php 
                        if (isset($_GET['Lupdate']) && $_GET['Lupdate'] == 'updateL' && $_GET['id'] != null) {
                        ?>
                        <input type="hidden" id="LID" name="LID" value="<?= $_GET['id'] ?>">
                        <input type="submit" class="btn btn-secondary btn-sm" name="speichernLF" value="speichern"
                            id="SL">
                        <?php
                        } else {
                        ?>
                        <input type="submit" class="btn btn-secondary btn-sm" name="speichernL" value="speichern"
                            id="SL">
                        <?php
                        }
                        ?>
                    </div>
                </form>
            </form>
        </div>
    </div>
</div>

<?php
    if(isset($_GET['Lupdate']) && $_GET['Lupdate'] == 'updateL' && $_GET['id'] != null)
    {
        ?>
<script>
$("#frmAddLieferanten").slideToggle();
</script>
<?
    }
    ?>

<?php
//Html::pre_print_r( PDO::getAvailableDrivers() );

$pdo = new PDO(DSN, DBUSER, DBPWD);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//Html::pre_print_r($pdo);


$todo = filter_input(INPUT_GET, "todo", FILTER_SANITIZE_STRING);
$id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
//$idL = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);

//---Datensatz / Lieferant anlegen & speichen----------------------------------
$speichernL = filter_input(INPUT_POST, "speichernL", FILTER_SANITIZE_STRING);
if (!is_null($speichernL)) {
    
    $idLL = filter_input(INPUT_POST, "id", FILTER_SANITIZE_STRING);
    $vornameL = filter_input(INPUT_POST, "LVorname", FILTER_SANITIZE_STRING);
    $nachnameL = filter_input(INPUT_POST, "LNachname", FILTER_SANITIZE_STRING);
    $plzL = filter_input(INPUT_POST, "LPLZ", FILTER_SANITIZE_STRING);
    $emailL = filter_input(INPUT_POST, "LEmail", FILTER_SANITIZE_STRING);
    $telL = filter_input(INPUT_POST, "LTel", FILTER_SANITIZE_STRING);
    $strL = filter_input(INPUT_POST, "LStr", FILTER_SANITIZE_STRING);
    $landL = filter_input(INPUT_POST, "LLand", FILTER_SANITIZE_STRING);
    $stadtL = filter_input(INPUT_POST, "LCity", FILTER_SANITIZE_STRING);
    $firmaL = filter_input(INPUT_POST, "LFirma", FILTER_SANITIZE_STRING);
    $usertypeL = filter_input(INPUT_POST, "Lusertype", FILTER_SANITIZE_STRING);
    $passwortL = filter_input(INPUT_POST, "passwort", FILTER_SANITIZE_STRING);
    $passwortLH = password_hash($passwortL, PASSWORD_DEFAULT);

    $sqlInsert = "INSERT INTO lieferant(Firma, vorname, nachname, Strasse, PLZ, Stadt, Land, Email, Tel, user_type, passwort) VALUES('$firmaL', '$vornameL', '$nachnameL', '$strL',  '$plzL', '$stadtL', '$landL','$emailL', '$telL', '$usertypeL', '$passwortLH')";

    try {
        if ($pdo->exec($sqlInsert) === 1) {
            echo '<div class="alert alert-success">Ein neuer Lieferant wurde gespeichert</div>';
        }
    } catch (PDOException $fehler) {
        echo '<div>' . $fehler->getMessage() . '</div>';
        Html::pre_print_r($fehler);
    }
}

//UPDATE LIEFERANT START
$speichernLFF = filter_input(INPUT_POST, "speichernLF", FILTER_SANITIZE_STRING);
if (!is_null($speichernLFF)) {

    $options = [
        'cost' => 12,
    ];

    $idL = filter_input(INPUT_POST, "LID", FILTER_SANITIZE_STRING);
    $vornameL = filter_input(INPUT_POST, "LVorname", FILTER_SANITIZE_STRING);
    $nachnameL = filter_input(INPUT_POST, "LNachname", FILTER_SANITIZE_STRING);
    $plzL = filter_input(INPUT_POST, "LPLZ", FILTER_SANITIZE_STRING);
    $emailL = filter_input(INPUT_POST, "LEmail", FILTER_SANITIZE_STRING);
    $telL = filter_input(INPUT_POST, "LTel", FILTER_SANITIZE_STRING);
    $strL = filter_input(INPUT_POST, "LStr", FILTER_SANITIZE_STRING);
    $landL = filter_input(INPUT_POST, "LLand", FILTER_SANITIZE_STRING);
    $stadtL = filter_input(INPUT_POST, "LCity", FILTER_SANITIZE_STRING);
    $firmaL = filter_input(INPUT_POST, "LFirma", FILTER_SANITIZE_STRING);
    $usertypeL = filter_input(INPUT_POST, "Lusertype", FILTER_SANITIZE_STRING);
    $passwortL = filter_input(INPUT_POST, "passwort", FILTER_SANITIZE_STRING);
    $passwortLH = password_hash($passwortL, PASSWORD_DEFAULT);
    $sqlInsert = "UPDATE lieferant SET Firma=?, vorname=?, nachname=?, Strasse=?, PLZ=?, Stadt=?, Land=?, Email=?, Tel=?, user_type=?, passwort=? WHERE id=?";
    $stmt= $pdo->prepare($sqlInsert);
    try {
        if ($stmt->execute([$firmaL, $vornameL, $nachnameL, $strL, $plzL, $stadtL, $landL, $emailL, $telL, $usertypeL, $passwortLH, $idL]) === 1) {
            echo '<div class="alert alert-success">Die neu Artikel Daten wurde geändert</div>';
        }
    } catch (PDOException $fehler) {
        echo '<div>' . $fehler->getMessage() . '</div>';
        Html::pre_print_r($fehler);
    }

}
//UPDATE LIEFERANT STOP

//---Datensatz Kunden anlegen / speichen---------------------------------????????????????????????????????
$speichernK = filter_input(INPUT_POST, "speichernK", FILTER_SANITIZE_STRING);
if (!is_null($speichernK)) {

    $idK = $_SESSION["LieferantID"];
    $vornameK = filter_input(INPUT_POST, "Kvorname", FILTER_SANITIZE_STRING);
    $nachnameK = filter_input(INPUT_POST, "Knachname", FILTER_SANITIZE_STRING);
    $plzK = filter_input(INPUT_POST, "Kplz", FILTER_SANITIZE_STRING);
    $emailK = filter_input(INPUT_POST, "Kemail", FILTER_SANITIZE_STRING);
    $telK = filter_input(INPUT_POST, "Ktel", FILTER_SANITIZE_STRING);
    $strK = filter_input(INPUT_POST, "Kstr", FILTER_SANITIZE_STRING);
    $landK = filter_input(INPUT_POST, "Kland", FILTER_SANITIZE_STRING);
    $stadtK = filter_input(INPUT_POST, "Kstadt", FILTER_SANITIZE_STRING);
    $firmaK = filter_input(INPUT_POST, "Kfirma", FILTER_SANITIZE_STRING);

    $sqlInsert = "INSERT INTO kunden(lieferantID, Firma, vorname, nachname, Strasse, PLZ, Stadt, Land, Email, Tel) VALUES('$idK', '$firmaK', '$vornameK','$nachnameK', '$strK', '$plzK', '$stadtK', '$landK', '$emailK', '$telK')";

    try {
        if ($pdo->exec($sqlInsert) === 1) {
            echo '<div class="alert alert-success">Ein neuer Kunde wurde gespeichert</div>';
        }
    } catch (PDOException $fehler) {
        echo '<div>' . $fehler->getMessage() . '</div>';
        Html::pre_print_r($fehler);
    }
}

//UPDATE KUNDE START
$speichernKFinal = filter_input(INPUT_POST, "speichernKFinll", FILTER_SANITIZE_STRING);
if (!is_null($speichernKFinal)) {

    $idK = filter_input(INPUT_POST, "custID", FILTER_SANITIZE_STRING);
    $vornameK = filter_input(INPUT_POST, "Kvorname", FILTER_SANITIZE_STRING);
    $nachnameK = filter_input(INPUT_POST, "Knachname", FILTER_SANITIZE_STRING);
    $plzK = filter_input(INPUT_POST, "Kplz", FILTER_SANITIZE_STRING);
    $emailK = filter_input(INPUT_POST, "Kemail", FILTER_SANITIZE_STRING);
    $telK = filter_input(INPUT_POST, "Ktel", FILTER_SANITIZE_STRING);
    $strK = filter_input(INPUT_POST, "Kstr", FILTER_SANITIZE_STRING);
    $landK = filter_input(INPUT_POST, "Kland", FILTER_SANITIZE_STRING);
    $stadtK = filter_input(INPUT_POST, "Kstadt", FILTER_SANITIZE_STRING);
    $firmaK = filter_input(INPUT_POST, "Kfirma", FILTER_SANITIZE_STRING);
    var_dump($idK);
    $sqlInsert = "UPDATE kunden SET Firma=?, vorname=?, nachname=?, Strasse=?, PLZ=?, Stadt=?, Land=?, Email=?, Tel=? WHERE id=?";
    $stmt= $pdo->prepare($sqlInsert);
    try {
        if ($stmt->execute([$firmaK, $vornameK, $nachnameK, $strK, $plzK, $stadtK, $landK, $emailK, $telK, $idK]) === 1) {
            echo '<div class="alert alert-success">Ein neuer Kunde wurde gespeichert</div>';
        }
    } catch (PDOException $fehler) {
        echo '<div>' . $fehler->getMessage() . '</div>';
        Html::pre_print_r($fehler);
    }

}
//UPDATE KUNDE STOP

//---/Datensatz speichen----------------------------------
$speichernA = filter_input(INPUT_POST, "speichernArt", FILTER_SANITIZE_STRING);
if (!is_null($speichernA)) {
    
    $nameA = filter_input(INPUT_POST, "artikel", FILTER_SANITIZE_STRING);
    $preis = filter_input(INPUT_POST, "preis", FILTER_SANITIZE_STRING);
    $bestand = filter_input(INPUT_POST, "bestand", FILTER_SANITIZE_STRING); 
    $artNr = filter_input(INPUT_POST, "ArtNr", FILTER_SANITIZE_STRING);
    $lifID = $_SESSION["LieferantID"];

    $sqlInsert = "INSERT INTO artikel(LieferantID, ArtikelNr, name, preis, bestand) VALUES('$lifID', '$artNr', '$nameA', '$preis', '$bestand')";

    //echo $sqlInsert;
    try {
        if ($pdo->exec($sqlInsert) === 1) {
           $betreff = "ASIG BESTELLUNG";
        $from="s090783@gmail.com";
        mail($from, $betreff, "Send mail from localhost using PHP"); ///////EMAIL VOM SERVER AN LIEFERANTEN SENDEN
            echo '<div class="alert alert-success">Ein neuer Artikel wurde gespeichert</div>';
          // $from = "From: Roman Schulz <s090783@gmail.com>";
           //$text = "$ergebnisK, $aData2, $sqlInsert";
        

        }
    } catch (PDOException $fehler) {
        echo '<div>' . $fehler->getMessage() . '</div>';
        Html::pre_print_r($fehler);
    }
}
//UPDATE ARTIKEL START
$speichernAA = filter_input(INPUT_POST, "speichernAA", FILTER_SANITIZE_STRING);
if (!is_null($speichernAA)) {

    $idA = filter_input(INPUT_POST, "AID", FILTER_SANITIZE_STRING);
    $nameA = filter_input(INPUT_POST, "artikel", FILTER_SANITIZE_STRING);
    $preis = filter_input(INPUT_POST, "preis", FILTER_SANITIZE_STRING);
    $bestand = filter_input(INPUT_POST, "bestand", FILTER_SANITIZE_STRING);
    $artNr = filter_input(INPUT_POST, "ArtNr", FILTER_SANITIZE_STRING);

    $sqlInsert = "UPDATE artikel SET ArtikelNr=?, name=?, preis=?, bestand=? WHERE ID=?";
    $stmt= $pdo->prepare($sqlInsert);
    try {
        if ($stmt->execute([$artNr, $nameA,  $preis, $bestand, $idA]) === 1) {
            echo '<div class="alert alert-success">Die neu Artikel Daten wurde geändert</div>';
        }
    } catch (PDOException $fehler) {
        echo '<div>' . $fehler->getMessage() . '</div>';
        Html::pre_print_r($fehler);
    }

}
//UPDATE ARTIKEL STOP

////////////////////Artikel löschen und bearbeiten
$ergebnis2 = $pdo->query("SELECT * FROM artikel WHERE LieferantID = '".$_SESSION["LieferantID"]."'"); //
$aData2 = $ergebnis2->fetchAll(PDO::FETCH_ASSOC);

for($i=0; $i < count($aData2); $i++) { 
    if(isset($_SESSION["admin"]) && $_SESSION['admin'] == 'administrator' || $_SESSION['admin'] == 'lieferant'){ 
        $aData2[$i]["delete"] = '<a href="pdo.php?todo=deleteArt&id='.$aData2[$i]["ID"].'" class="btn btn-secondary btn-sm">Artikel löschen</a> <a href="pdo.php?updatea=updateA&ID='.$aData2[$i]["ID"].'" class="btn btn-secondary btn-sm">Artikel bearbeiten</a>';
    }
}


//Artikel Tabelle mit 2 DIM array
$aCfg2["TBL_CLASS"] = "table table-striped";
echo Html::createTableFromArrayArtikel($aData2, $aCfg2);


////////for LIEFERANTEN
$ergebnisL = $pdo->query("SELECT * FROM lieferant "); 
$aDataL = $ergebnisL->fetchAll(PDO::FETCH_ASSOC);

for($i=0; $i < count($aDataL); $i++) { 
    if(isset($_SESSION['admin']) && $_SESSION['admin'] == 'administrator') {  
        $aDataL[$i]["delete"] = '<a href="pdo.php?todo=deleteL&id='.$aDataL[$i]["id"].'" class="btn btn-secondary btn-sm">Lieferant löschen</a> <a href="pdo.php?Lupdate=updateL&id='.$aDataL[$i]["id"].'" class="btn btn-secondary btn-sm">Lieferant bearbeiten</a>';
    }
}

//Lieferanten Tabelle mit EINEM 2 DIM array
if( $_SESSION['admin'] == 'administrator') {
$aCfgL["TBL_CLASS"] = "table table-striped";
echo Html::createTableFromArray($aDataL, $aCfgL);
}
////////KUNDEN löschen und bearbeiten
$ergebnisK = $pdo->query("SELECT * FROM kunden  WHERE LieferantID = '".$_SESSION["LieferantID"]."'"); 
$aDataK = $ergebnisK->fetchAll(PDO::FETCH_ASSOC);

for($i=0; $i < count($aDataK); $i++) { 
    if(isset($_SESSION['admin']) && $_SESSION['admin'] == 'administrator' || $_SESSION['admin'] == 'lieferant'){  
        $aDataK[$i]["delete"] = '<a href="pdo.php?todo=deleteK&id='.$aDataK[$i]["id"].'" class="btn btn-secondary btn-sm">Kunde löschen</a> <a href="pdo.php?updatek=updateK&id='.$aDataK[$i]["id"].'" class="btn btn-secondary btn-sm">Kunde bearbeiten</a>';
    }            
}


//KUNDEN TABELLE BEARBEITEN



//KUNDEN Tabelle mit EINEM 2 DIM array
$aCfgK["TBL_CLASS"] = "table table-striped";
echo Html::createTableFromArray($aDataK, $aCfgK);

if ($todo === "deleteArt") {
    $sql = "DELETE FROM artikel WHERE ID = $id";
    //echo $sql;
    if (1 === $pdo->exec($sql)) {
        echo '<div>Dieser Artikel wurde gelöscht</div>';
    } else {
        echo '<div>Es wurde kein Datensatz gelöscht</div>';
    }
}

if ($todo === "deleteK") {
    $sql = "DELETE FROM kunden WHERE  id = $id";
    //echo $sql;
    if (1 === $pdo->exec($sql)) {
        echo '<div>Dieser Kunde wurde gelöscht</div>';
    } else {
        echo '<div>Es wurde kein Datensatz gelöscht</div>';
    }
}

if ($todo === "deleteL") {
    $sql = "DELETE FROM lieferant WHERE id = $id";
    //echo $sql;
    if (1 === $pdo->exec($sql)) {
        echo '<div>Dieser Lieferant wurde gelöscht</div>';
    } else {
        echo '<div>Es wurde kein Datensatz gelöscht</div>';
    }
}

if ($todo === "updateKF") {
    //$sql = "DELETE FROM lieferant WHERE id = $id";
    //echo $sql;
    if (1 === $pdo->exec($sql)) {
        echo '<div>Der Datensatz wurde gelöscht</div>';
    } else {
        echo '<div>Es wurde kein Datensatz gelöscht</div>';
    }
}

//Html::pre_print_r($aData);
echo "</div>"; //div class=container
echo Html::closeHtmlBody();
echo Html::closeHtmlHtml();