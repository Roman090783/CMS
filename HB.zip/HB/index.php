


        <?php
        
require_once $_SERVER["DOCUMENT_ROOT"].'/HB/inc/constants.inc.php';
require_once $_SERVER["DOCUMENT_ROOT"].'//inc/classes/class.html.inc.php';

$errmsg = "";

//Abmeldung
if(isset($_GET["logout"])) {
    session_destroy();
    header("Location: /HB/pdo.php");
    exit;
}

//Html::pre_print_r($_POST);

$anmelden = filter_input(INPUT_POST, "anmelden", FILTER_SANITIZE_STRING);
$formPwd = filter_input(INPUT_POST, "formPwd", FILTER_SANITIZE_STRING);
$formUser = filter_input(INPUT_POST, "formUser", FILTER_SANITIZE_STRING);

if(!is_null($anmelden)) {
    if($formUser === WEBUSER && $formPwd === WEBPWD) {
        //Anmeldung ok
        $_SESSION["admin"] = $formUser;
        $_SESSION["anmeldung"] = date("d.m.Y H:i:s");
        header("Location: /HB/pdo.php");
    } else {
        $errmsg = Html::alert("Die Anmeldung ist fehlgeschlagen.", "warning");
    }
}

echo Html::getDoctype();
echo Html::openHtmlHtml();

$aCfg["TITLE"] = "Vorlage";
echo Html::openHtmlHead($aCfg);
?>
<style>
</style>
<script>
</script>
<?php
echo Html::closeHtmlHead();
echo Html::openHtmlBody();
echo '<div class="container">';
?>

<div>
    <h1>Login</h1>

    <form action="index.php" method="POST">
        <?php echo $errmsg; ?>
        
            <div class="form-group">                
                <label for="elUser">User: </label>
                <input type="" name="formUser" class="form-control" value="" id="elUser">
            </div>
            <div class="form-group">
                <label for="elPwd">Paswort: </label>
                <input type="password" name="formPwd" required class="form-control" value="" id="elPwd">
            </div>
            <div>
                <input type="submit" class="btn btn-secondary btn-sm" name="anmelden" value="anmelden">
            </div>
        </form>
        
</div>


<?php
echo "</div>"; // div class=container
echo Html::closeHtmlBody();
echo Html::closeHtmlHtml();

//highlight_file(__FILE__);
    //</body>
//</html>
