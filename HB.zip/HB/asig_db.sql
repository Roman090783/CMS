-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 07. Mai 2020 um 17:58
-- Server-Version: 10.1.34-MariaDB
-- PHP-Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `asig_db`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `adressen`
--

CREATE TABLE `adressen` (
  `id` int(10) UNSIGNED NOT NULL,
  `vorname` varchar(30) NOT NULL,
  `passwort` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `nachname` varchar(40) NOT NULL,
  `PLZ` int(30) NOT NULL,
  `Land` varchar(50) NOT NULL,
  `Stadt` varchar(50) NOT NULL,
  `Strasse` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Tel` varchar(100) NOT NULL,
  `Firma` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `adressen`
--

INSERT INTO `adressen` (`id`, `vorname`, `passwort`, `user_type`, `nachname`, `PLZ`, `Land`, `Stadt`, `Strasse`, `Email`, `Tel`, `Firma`) VALUES
(90, 'L', '1111', 'lieferant', 'Schulz', 52066, 'Deutschland', 'Aachen', 'Zollerstr.4', 's090783@gmail.com', '015736597314', 'ADHOC'),
(91, 'Roman', '000', 'administrator', 'Schulz', 52066, 'Deutschland', 'Aachen', 'Zollerstr.4', 's090783@gmail.com', '015736597314', 'ADHOC'),
(92, 'A', '1', 'lieferant', 'Schulz', 52066, 'Deutschland', 'Aachen', 'Hauptstr. 78', 's090783@gmail.com', '015736597314', 'RS');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `artikel`
--

CREATE TABLE `artikel` (
  `name` varchar(100) NOT NULL,
  `preis` int(255) NOT NULL,
  `bestand` int(255) NOT NULL,
  `LieferantID` int(255) NOT NULL,
  `ID` int(11) NOT NULL,
  `ArtikelNr` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `artikel`
--

INSERT INTO `artikel` (`name`, `preis`, `bestand`, `LieferantID`, `ID`, `ArtikelNr`) VALUES
('Wasser', 2147483647, 111, 81, 2, ''),
('SHOKO', 999, 2, 81, 4, 'qwert'),
('MANGO', 5, 1000, 81, 6, 'M1 AFRICA'),
('SEME$KI', 70, 333, 81, 7, 'RUSS'),
('MILCH', 1, 500, 81, 8, 'M2'),
('SHOKO', 1, 100000, 91, 11, 'M1 AFRICA');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunden`
--

CREATE TABLE `kunden` (
  `id` int(10) UNSIGNED NOT NULL,
  `lieferantID` int(10) UNSIGNED NOT NULL,
  `vorname` varchar(30) NOT NULL,
  `nachname` varchar(40) NOT NULL,
  `PLZ` int(30) NOT NULL,
  `Land` varchar(50) NOT NULL,
  `Stadt` varchar(50) NOT NULL,
  `Strasse` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Tel` varchar(100) NOT NULL,
  `Firma` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `kunden`
--

INSERT INTO `kunden` (`id`, `lieferantID`, `vorname`, `nachname`, `PLZ`, `Land`, `Stadt`, `Strasse`, `Email`, `Tel`, `Firma`) VALUES
(11, 90, 'Maria', 'Schulz', 52066, 'Deutschland', 'Aachen', 'Hauptstr. 78', 's090783@gmail.com', '015736597314', 'RS'),
(12, 91, 'Maria', 'Schulz', 52066, 'Deutschland', 'Aachen', 'Hauptstr. 78', 's090783@gmail.com', '015736597314', 'RS');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `adressen`
--
ALTER TABLE `adressen`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `LieferantID` (`LieferantID`);

--
-- Indizes für die Tabelle `kunden`
--
ALTER TABLE `kunden`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD UNIQUE KEY `id_5` (`id`),
  ADD KEY `lieferantID` (`lieferantID`),
  ADD KEY `id_3` (`id`),
  ADD KEY `id_4` (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `adressen`
--
ALTER TABLE `adressen`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT für Tabelle `artikel`
--
ALTER TABLE `artikel`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT für Tabelle `kunden`
--
ALTER TABLE `kunden`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `kunden`
--
ALTER TABLE `kunden`
  ADD CONSTRAINT `kunden_ibfk_1` FOREIGN KEY (`lieferantID`) REFERENCES `adressen` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
