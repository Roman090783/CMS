<?php

require_once $_SERVER["DOCUMENT_ROOT"] . '/HB/inc/constants.inc.php';

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Name'])) //isset($_POST['Name'])
{

    $pdo = new PDO(DSN, DBUSER, DBPWD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $dataNeme = $_POST['Name'];
    $artiklNummer = $_POST['artNum'];

    $dataNeme2 = $pdo->query("SELECT * FROM artikel WHERE ArtikelNr = '".$artiklNummer."'"); //
    $dataNeme2->execute();
    //$aData2 = $$dataNeme2->execute(PDO::FETCH_ASSOC);
    $aData2 = $dataNeme2->fetch();
    echo('Kunde:  ' . $dataNeme . ' , Artikel-Nr. ' . $artiklNummer . ' , Preis in EUR: ' . $aData2['preis']);
    //echo($aData2['preis']);
// for($i=0; $i < count($aData2); $i++) { 
//             if(isset($_SESSION["admin"]) && $_SESSION['admin'] == 'administrator' || $_SESSION['admin'] == 'lieferant'){ 
//                 $aData2[$i]["delete"] = '<a href="pdo.php?todo=deleteArt&id='.$aData2[$i]["ID"].'" class="btn btn-secondary btn-sm">Artikel löschen</a> <a href="pdo.php?updatea=updateA&ID='.$aData2[$i]["ID"].'" class="btn btn-secondary btn-sm">Artikel bearbeiten</a>';
//             }
//         } 


//Artikel Tabelle mit 2 DIM array
echo('<br>');
echo('<br>');
//echo($aData2);
echo('<br>');
echo('<br>');
echo('OK!');
echo('<br>');
echo($dataNeme);

} else {
    echo('ERROR!!! = Keine post');
}
?>
