<?php
require_once $_SERVER["DOCUMENT_ROOT"].'/HB/inc/constants.inc.php';

$errmsg = "";

//Abmeldung
if(isset($_GET["logout"])) {
    session_destroy();
    header("Location: pdo.php");
    exit;
}

//Html::pre_print_r($_POST); // TEST

$anmelden = filter_input(INPUT_POST, "anmelden", FILTER_SANITIZE_STRING);
$formPwd = filter_input(INPUT_POST, "formPwd", FILTER_SANITIZE_STRING);

$formUser = filter_input(INPUT_POST, "formUser", FILTER_SANITIZE_STRING);






if(!is_null($anmelden)) {
    $pdo = new PDO(DSN, DBUSER, DBPWD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $selectUser = $pdo->query("SELECT * FROM lieferant WHERE vorname = '".$formUser."'"); //
    $checkUser = $selectUser->fetch();
    //var_dump($checkUser);
    //echo('<br>');
    //echo('1. form = ' . $formPwd . '<br> 2. mysql = ' . $checkUser['passwort'] . '');
    //exit;
    //var_dump("SELECT * FROM lieferant WHERE vorname = '".$formUser."' AND passwort = '".$formPwd."'");
    //exit;
    if($formUser === $checkUser['vorname']){ //&& $formPwd === $checkUser['passwort']) {
        //Anmeldung ok
        if(password_verify($formPwd, $checkUser['passwort'])) {
            $_SESSION["admin"] = $checkUser['user_type'];
            $_SESSION["LieferantID"] = $checkUser['id'];

            $_SESSION["anmeldung"] = date("d.m.Y H:i:s");
            header("Location: pdo.php");
        }else {
            $errmsg = Html::alert("2. Die Anmeldung ist fehlgeschlagen.", "warning");
        }
    } else {
        $errmsg = Html::alert("1. Die Anmeldung ist fehlgeschlagen.", "warning");
    }
}

echo Html::getDoctype();
echo Html::openHtmlHtml();

$aCfg["TITLE"] = "Vorlage";
echo Html::openHtmlHead($aCfg);

echo Html::closeHtmlHead();
echo Html::openHtmlBody();
echo '<div class="container">';
?>

<div>
    <h1>Login</h1>

    <form action="login.php" method="POST">
        <?php echo $errmsg; ?>

        <div class="form-group">
            <label for="elUser">Benutzer: </label>
            <input type="" name="formUser" class="form-control" value="" id="elUser">
        </div>
        <div class="form-group">
            <label for="elPwd">Passwort: </label>
            <input type="password" name="formPwd" required class="form-control" value="" id="elPwd">
        </div>
       

            <div class="text-center">
                <input type="submit" class="btn btn-primary btn-lg" name="anmelden" value="anmelden">
            
               <!--  <input type="submit" class="btn btn-secondary btn-lg" name="registrieren" value="registrieren"> -->
            </div>
        </div>

    </form>

</div>


<?php
echo "</div>"; // div class=container
echo Html::closeHtmlBody();
echo Html::closeHtmlHtml();
//highlight_file(__FILE__);