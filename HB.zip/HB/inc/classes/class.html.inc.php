<?php

class Html {

    /**
     * HTML Doctype
     * 
     * @access public
     * @static
     * @return string den kompletten HTML Doctype
     */
    public static function getDoctype() {
        return '<!DOCTYPE html>';
    }

    public static function openHtmlHtml() {
        return '<html>';
    }

    public static function closeHtmlHtml() {
        return '</html>';
    }

    public static function openHtmlHead($aConfig = []) {

        $title = (isset($aConfig["TITLE"])) ? $aConfig["TITLE"] : "default Seitentitel";

        $s = '<head>
        <meta charset="UTF-8">
        <title>' . $title . '</title>
        <link rel="stylesheet" href="/HB/node_modules/bootstrap/dist/css/bootstrap.min.css">
        <script src="./node_modules/jquery/dist/jquery.min.js"></script>';
        return $s;
    }

    public static function closeHtmlHead() {
        return '</head>';
    }

    public static function openHtmlBody() {
        $s = '<body>';
        return $s;
    }

    public static function closeHtmlBody() {
        return '</body>';
    }

    public static function pre_print_r($v) {
        echo "<pre>";
        print_r($v);
        echo "</pre>";
    }

    public static function createTableFromArray($aData, $aConfig = []) {

        $tbl_class = (isset($aConfig["TBL_CLASS"])) ? ' class="' . $aConfig["TBL_CLASS"] . '"' : '';

        if (!is_array($aData)) {
            return "<div>Die Daten sind kein Array</div>";
        }
        $s = "<table$tbl_class>";
        foreach ($aData as $v) {
            if (is_array($v)) {
                //mind 2 dim Array
                $s .= "<tr>";
                foreach ($v as $v2) {
                    $s .= "<td>$v2</td>";
                }
                $s .= "</tr>";
            } else {
                // 1 dim Array
                $s .= "<tr><td>$v<tr><td>";
            }
        }
        $s .= '</table>';
        return $s;
    }


    public static function createTableFromArrayArtikel($aData, $aConfig = []) {

        $tbl_class = (isset($aConfig["TBL_CLASS"])) ? ' class="' . $aConfig["TBL_CLASS"] . '"' : '';

        if (!is_array($aData)) {
            return "<div>Die Daten sind kein Array</div>";
        }
        $s = "<table$tbl_class>";
        foreach ($aData as $v) {
            if (is_array($v)) {
                //mind 2 dim Array
                $s .= "<tr>";
                foreach ($v as $v2) {
                    $s .= "<td>$v2</td>";
                }
                $s .= "</tr>";
            } else {
                // 1 dim Array
                $s .= "<tr><td>$v<tr><td>";
            }
        }
        $s .= '</table>';
        return $s;
    }



    public static function alert($text, $style = "info") {
        switch ($style) {
            case "warning":
                $s = "<div class=\"alert alert-warning\">$text</div>";
                break;
            case "success":
                $s = "<div class=\"alert alert-success\">$text</div>";
                break;
            default:
                $s = "<div class=\"alert alert-info\">$text</div>";
        }
        return $s;
    }

}