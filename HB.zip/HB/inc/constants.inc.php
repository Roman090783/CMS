<?php

session_start();

const DSN = 'mysql:host=localhost;dbname=asig_db';
const DBUSER = 'root';
const DBPWD = '';

//const WEBUSER = "Roman";
//const WEBPWD = "roman";

function __autoload($klasse) {
    require_once $_SERVER["DOCUMENT_ROOT"] . '/HB/inc/classes/class.' . strtolower($klasse) . '.inc.php';
}
