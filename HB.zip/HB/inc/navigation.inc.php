
<nav>
    
<?php
    //if(isset($_SESSION["LieferantID"])){
    if($_SESSION["admin"] == 'administrator') {
    ?>
    <a href ="pdo.php"class="btn btn-primary btn-sm" id="btnStart">Neu laden</a>
    <button class="btn btn-primary btn-sm" id="btnAddNew">Kunden anlegen</button>
    <button class="btn btn-primary btn-sm" id="btnAddLiferant">Lieferanten anlegen</button>
    <button class="btn btn-primary btn-sm" id="btnAddArtikel">Artikel anlegen</button>
    <?php
    } else if($_SESSION["admin"] == 'lieferant') {
    ?>
    <button class="btn btn-primary btn-sm" id="btnAddArtikel">Artikel anlegen</button>
    <button class="btn btn-primary btn-sm" id="btnAddNew">Kunden anlegen</button>
    <?php
    }
    if (!isset($_SESSION["admin"])) { ?>
        <a href="login.php" class="btn btn-primary btn-sm">Einloggen</a>
    <?php } else { ?>
        <a href="logout.php" class="btn btn-primary btn-sm">Ausloggen</a>
    <?php } 
    //}
    ?>
</nav>  